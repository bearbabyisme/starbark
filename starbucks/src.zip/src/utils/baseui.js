import Header from '../components/header.vue'
export default {
    install(Vue){
        Vue.component('Header',Header)
    }
}