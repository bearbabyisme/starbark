<template>
    <div class="wrapper">
        <Header title="详情"/>
        
    </div>
</template>
<script>
import request from '../../utils/request'
import {mapActions} from 'vuex'
export default {
    props:{
        type:String,
        id:String
    },
    components:{

    },
    data(){
        return {

        }
    },
    computed:{

    },
    methods:{
        ...mapActions('user',['getUserInfo'])
    },
    created(){
        this.getUserInfo()
        request.get(`/api/apply/${this.type}`,{applicationNumber:this.id}).then(res=>{
            console.log(res)
        })
    },
    mounted(){

    }
}
</script>
<style scoped lang="">

</style>