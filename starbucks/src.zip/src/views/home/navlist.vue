<template>
    <div>

    </div>
</template>
<script>
export default {
    props:{

    },
    components:{

    },
    data(){
        return {
            ind:0,
            list:[{
                title:"加班",
                type:"overtime"
            },{
                title:"休假",
                type:"vacation"
            }],
        }
    },
    computed:{

    },
    methods:{

    },
    created(){

    },
    mounted(){

    }
}
</script>
<style scoped lang="">

</style>