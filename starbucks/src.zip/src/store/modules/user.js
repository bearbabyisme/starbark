import request from '../../utils/request'
export default {
    namespaced:true,
    state:{
        list:{}
    },
    mutations:{
        getuser(state,data){
            state.list = data
        }
    },
    actions:{
        getUserInfo({commit}){
            request.get('/api/user/info').then(res => {
                // console.log(res.data)
                commit("getuser",res.data)
            })
        }
    }
}