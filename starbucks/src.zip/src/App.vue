<template>
  <div id="app">
      <router-view/>
  </div>
</template>
<script>
export default {
}
</script>

<style lang="scss">
@import './static/css/_minix.scss';
@import './static/css/common.scss';

</style>

