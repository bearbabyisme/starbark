<template>
  <div class="wrapper">
    <button @click="openFn">+ 发起任务</button>
    <div class="mask" v-show="flag">
        <div class="mask_main">

        </div>
        <div class="mask_footer">
              <div class="item" v-for="(item,index) in list" :key="index">
                <i :class="item.icon" :style="{color:item.color}"></i>
                <span>{{item.title}}</span>
            </div>
            
            
        </div>
    </div>
    <Header title="加班/休假">
      <span>返回</span>
      <span>搜索</span>
    </Header>
    <div class="nav">
      <div class="item">
        <router-link to="/index/wait">
          <i class="iconfont icon-05"></i>
          <span>待处理</span>
        </router-link>
      </div>
      <div class="item">
        <router-link to="/index/send">
          <i class="iconfont icon-07"></i>
          <span>已发送</span>
        </router-link>
      </div>
      <div class="item">
        <router-link to="/index/end">
          <i class="iconfont icon-yibangding"></i>
          <span>已处理</span>
        </router-link>
      </div>
    </div>
    <main class="main">
      <router-view></router-view>
    </main>
  </div>
</template>
<script>
export default {
  props: {},
  components: {},
  data() {
    return {
      list:[{
                title:"加班",
                type:"overtime",
                icon:"iconfont icon-guangpan",
                color:"#ffaa3c"
            },{
                title:"休假",
                type:"vacation",
                icon:"iconfont icon-fengjing",
                color:"#6bbb62"
            }],
      flag:false      
    };
  },
  computed: {},
  methods: {
    openFn(){
       this.flag = true
    }
  },
  created() {},
  mounted() {}
};
</script>
<style scoped lang="scss">
@import "../static/css/_minix.scss";
@import "../static/css/common.scss";
.wrapper {
  @include width(100%);
  @include height(100%);
  display: flex;
  flex-direction: column;
  position: relative;
  .mask{
    @include width(100%);
    @include height(100%);
    position: absolute;
    background: rgba($color: #000000, $alpha:.5);
    z-index: 99;
    display: flex;
    flex-direction: column;
    .mask_main{
      width: 100%;
      flex: 1;
    }
    .mask_footer{
      width: 100%;
      height:pxTorem(120px);
      background: #fff;
      display: flex;
      .item{
        flex: 1;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        i{
          margin-bottom: 10px;
          font-size: pxTorem(22px)
        }
        span{
          font-size: pxTorem(12px)
        }
      }
    }
  }
  button{
    width: 28%;
    height: pxTorem(40px);
    border-radius: 50px;
    border: none;
    outline-style: none;
    position: absolute;
    bottom:3%;
    right:5%;
    background: #096242;
    color:#fff;
    font-size: pxTorem(13px);
  }
  .nav {
    @include width(100%);
    @include height(pxTorem(100px));
    display: flex;
    border-bottom: 1px solid #ccc;
    box-shadow: 0 20px 20px #eee;
    .item {
      flex: 1;
      display: flex;

      i {
        margin-top: 10px;
        font-size: pxTorem(20px);
        color: #ddd;
      }
      a {
        width: 100%;
        height: 100%;
        font-size: pxTorem(13px);
        text-decoration: none;
        color: #ddd;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
      }
      .router-link-exact-active {
        i {
          color: #096242;
        }
        span {
          color: #096242;
        }
      }
    }
  }
  .main {
    @include width(100%);
    flex: 1;
    font-size: pxTorem(13px);
  }
}
</style>