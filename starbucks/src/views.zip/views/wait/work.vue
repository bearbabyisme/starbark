<template>
    <div class="work">
        
    </div>
</template>
<script>

export default {
    props:{

    },
    components:{

    },
    data(){
        return {
            
        }
    },
    computed:{

    },
    methods:{

    },
    created(){
       
    },
    mounted(){

    }
}
</script>
<style scoped lang="scss">
@import "../../static/css/_minix.scss";
@import "../../static/css/common.scss";
.work{
    @include width(100%);
    @include height(100%);
    }
</style>