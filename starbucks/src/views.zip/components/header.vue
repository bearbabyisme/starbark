<template>
  <div class="header">
    <i class="iconfont icon-arrow-left arrow-right"></i>
    <span>{{title}}</span>
    <p> 
      <i class="iconfont icon-riqixuanze"></i>
      <i class="iconfont icon-fangdajing"></i>
    </p>
   
  </div>
</template>
<script>
export default {
  props: ["title"],
  components: {},
  data() {
    return {};
  },
  computed: {},
  methods: {},
  created() {},
  mounted() {}
};
</script>
<style scoped lang="scss">
@import "../static/css/_minix.scss";
@import "../static/css/common.scss";
.header {
  @include width(90%);
  @include height(pxTorem(45px));
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 5%;
  span {
    font-size: pxTorem(16px);
    margin-left: 3%;
  }
  i{
      font-size:pxTorem(20px); 
  }
  p{
    width:15%;
    display: flex;
    justify-content: space-around;
    align-items: center;
    i{
      margin-right: 30px;
      font-size:pxTorem(17px); 
    }
  }
}
</style>